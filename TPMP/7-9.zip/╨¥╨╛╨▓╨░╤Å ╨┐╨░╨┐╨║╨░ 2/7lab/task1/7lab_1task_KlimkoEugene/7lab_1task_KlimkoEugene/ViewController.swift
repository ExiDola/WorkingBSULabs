//
//  ViewController.swift
//  7lab_1task_KokhanDaniil
//
//  Created by MacOSExi on 14.05.24.
//  Copyright © 2024 MacOSExi. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var labelInd: UILabel!
    @IBOutlet var SwitchBut: UISwitch!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        SwitchBut.addTarget(self, action: #selector(backgroundSwitchTapped(_:)), for: .valueChanged)
    }

   // Добавляем целевой метод для переключателя SwitchBut
   

   // Метод, вызываемый при нажатии на переключатель SwitchBut
   @objc func backgroundSwitchTapped(_ sender: UISwitch) {
       if sender.isOn {
           labelInd.text = "inage1.jpg"
           view.backgroundColor = UIColor(patternImage: UIImage(named: "image1.1-1")!)
       } else {
           labelInd.text = "image2.jpg"
           view.backgroundColor = UIColor(patternImage: UIImage(named: "image2-1")!)
       }
   }

}
