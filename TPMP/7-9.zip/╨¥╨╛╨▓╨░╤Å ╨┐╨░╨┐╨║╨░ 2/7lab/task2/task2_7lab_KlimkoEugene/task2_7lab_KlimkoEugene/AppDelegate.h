//
//  AppDelegate.h
//  task2_7lab_KokhanDaniil
//
//  Created by MacOSExi on 14.05.24.
//  Copyright © 2024 MacOSExi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

