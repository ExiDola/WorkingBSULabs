//
//  SceneDelegate.h
//  task2_7lab_KokhanDaniil
//
//  Created by MacOSExi on 14.05.24.
//  Copyright © 2024 MacOSExi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

