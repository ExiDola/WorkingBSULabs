//
//  ViewController.h
//  task2_7lab_KokhanDaniil
//
//  Created by MacOSExi on 14.05.24.
//  Copyright © 2024 MacOSExi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property (weak, nonatomic) IBOutlet UITextField *cityField;
@property (weak, nonatomic) IBOutlet UIImageView *countryImageView;
@property (weak, nonatomic) IBOutlet UIImageView *memorialImageView;
@property (weak, nonatomic) IBOutlet UILabel *degreesLabel;
@property (weak, nonatomic) IBOutlet UILabel *countryName;
@property (weak, nonatomic) IBOutlet UILabel *memorialName;
@property (weak, nonatomic) IBOutlet UIButton *checkWeatherButton;
@end

