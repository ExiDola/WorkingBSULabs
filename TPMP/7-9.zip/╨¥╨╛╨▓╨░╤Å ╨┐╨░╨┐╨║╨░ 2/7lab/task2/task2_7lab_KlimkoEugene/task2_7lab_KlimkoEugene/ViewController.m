#import "ViewController.h"

@interface ViewController ()

@property (strong, nonatomic) NSDictionary *temperatureData;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.temperatureData = @{
        @"minsk": @{@"temperature": @10, @"country": @"Belarus", @"memorial": @"minsk_memorial", @"cityImage": @"minsk_country"},
        @"moscow": @{@"temperature": @15, @"country": @"Russia", @"memorial": @"moscow_memorial", @"cityImage": @"moscow_country"},
        @"warsaw": @{@"temperature": @20, @"country": @"Poland", @"memorial": @"warsaw_memorial", @"cityImage": @"warsaw_country"},
        @"gdansk": @{@"temperature": @20, @"country": @"Poland", @"memorial": @"warsaw_memorial", @"cityImage": @"warsaw_country"},
        @"rome": @{@"temperature": @28, @"country": @"Italy", @"memorial": @"rome_memorial", @"cityImage": @"rome_country"},
        @"venice": @{@"temperature": @18, @"country": @"Italy", @"memorial": @"rome_memorial", @"cityImage": @"rome_country"}
    };
}

- (IBAction)press:(id)sender {
    NSLog(@"Button pressed. Processing city...");

    // Убедитесь, что элементы интерфейса видимы
    [self.countryImageView setHidden:false];
    [self.memorialImageView setHidden:false];

    // Получаем город из текстового поля, приводим к нижнему регистру
    NSString *city = _cityField.text.lowercaseString;
    if ([city length] == 0) {
        [self.degreesLabel setText:@"Empty input!!!"];
        [self.countryName setText:@""];
        [self.memorialName setText:@""];
        NSLog(@"Empty input detected.");
        return;
    }
    
    // Ищем информацию о городе в словаре
    NSDictionary *cityData = self.temperatureData[city];
    if (cityData) {
        NSInteger tmp = [cityData[@"temperature"] integerValue];
        
        // Устанавливаем цвет текста в зависимости от температуры
        if (tmp < 12) {
            [self.degreesLabel setTextColor:[UIColor blueColor]];
        } else if (tmp < 27) {
            [self.degreesLabel setTextColor:[UIColor blackColor]];
        } else {
            [self.degreesLabel setTextColor:[UIColor redColor]];
        }
        
        // Обновляем текст метки и изображения
        self.degreesLabel.text = [NSString stringWithFormat:@"%ld°C", (long)tmp];
        [self.countryName setText:cityData[@"country"]];
        [self.memorialName setText:cityData[@"memorial"]];
        [self.countryImageView setImage:[UIImage imageNamed:cityData[@"cityImage"]]];
        [self.memorialImageView setImage:[UIImage imageNamed:cityData[@"memorial"]]];
        NSLog(@"City data found and UI updated.");
    } else {
        [self.degreesLabel setText:@"No such city"];
        [self.countryName setText:@"N/A"];
        [self.memorialName setText:@"N/A"];
        [self.countryImageView setHidden:true];
        [self.memorialImageView setHidden:true];
        NSLog(@"No data found for city: %@", city);
    }
}



@end
