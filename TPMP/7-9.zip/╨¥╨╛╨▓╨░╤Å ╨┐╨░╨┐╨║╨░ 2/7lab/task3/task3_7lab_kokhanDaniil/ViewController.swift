//
//  ViewController.swift
//  7lab_1task_KokhanDaniil
//
//  Created by MacOSExi on 14.05.24.
//  Copyright © 2024 MacOSExi. All rights reserved.
//


import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var calculateButton: UIButton!
    @IBOutlet weak var resultsLabel: UILabel!
    @IBOutlet weak var activitySegmentedControl: UISegmentedControl!
    @IBOutlet weak var sexSegmentControl: UISegmentedControl!
    @IBOutlet weak var weightTextField: UITextField!
    @IBOutlet weak var heightTextField: UITextField!
    @IBOutlet weak var ageTextField: UITextField!
    
    
    @IBAction func calculateTapped(_ sender: Any) {
        
        var BMR: Float = 0
        
        var height: Float = 0
        
        var weight: Float = 0
        
        if sexSegmentControl.selectedSegmentIndex == 1 {
            
            BMR = 447.593
            if let weightText = weightTextField.text, let temp = Float(weightText) {
                BMR = BMR + 9.247 * temp
                weight = temp
            }
            
            if let heightText = heightTextField.text, let temp = Float(heightText) {
                BMR = BMR + 3.098 * temp
                height = temp
            }
            
            if let ageText = ageTextField.text, let temp = Float(ageText) {
                BMR = BMR - 4.330 * temp
            }
            
        } else {
            BMR = 88.362
            if let weightText = weightTextField.text, let temp = Float(weightText) {
                BMR = BMR + 13.397 * temp
                weight = temp
            }
            
            if let heightText = heightTextField.text, let temp = Float(heightText) {
                BMR = BMR + 4.799 * temp
                height = temp
            }
            
            if let ageText = ageTextField.text, let temp = Float(ageText) {
                BMR = BMR - 5.677 * temp
            }
        }
        
        var AMR: Float = 0
        
        if activitySegmentedControl.selectedSegmentIndex == 0 {
            AMR = 1.2
        }
        
        if activitySegmentedControl.selectedSegmentIndex == 1 {
            AMR = 1.375
        }
        
        if activitySegmentedControl.selectedSegmentIndex == 2 {
            AMR = 1.55
        }
        
        if activitySegmentedControl.selectedSegmentIndex == 3 {
            AMR = 1.725
        }
        
        
        var result: Float = BMR * AMR
        result = result.rounded()
        
        var index: Float = weight / (height * height / 10000)
        index = index.rounded()
        
        resultsLabel.text = "Вы должны потреблять \(result) килокалорий для поддержания веса. Индекс массы тела \(index)"
        }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

