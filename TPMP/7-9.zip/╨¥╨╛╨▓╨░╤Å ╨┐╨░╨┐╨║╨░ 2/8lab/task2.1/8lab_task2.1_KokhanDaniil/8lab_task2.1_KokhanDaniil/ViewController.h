//
//  ViewController.h
//  8lab_task2.1_KokhanDaniil
//
//  Created by MacOSExi on 16.05.24.
//  Copyright © 2024 MacOSExi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

