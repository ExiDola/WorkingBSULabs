//
//  StudentTableViewCell.swift
//  9lab_task2.1_KokhnDaniil
//
//  Created by MacOSExi on 17.05.24.
//  Copyright © 2024 MacOSExi. All rights reserved.
//

import Foundation
import UIKit

class StudentTableViewCell: UITableViewCell {
    @IBOutlet weak var studentImageView: UIImageView!
    @IBOutlet weak var studentNameLabel: UILabel!
}
