//
//  Park+CoreDataClass.swift
//  9lab_task2.2_kokhanDaniil
//
//  Created by MacOSExi on 17.05.24.
//  Copyright © 2024 MacOSExi. All rights reserved.
//

import Foundation
import CoreData

@objc(Park)
public class Park: NSManagedObject {

}
