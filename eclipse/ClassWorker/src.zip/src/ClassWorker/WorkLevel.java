package ClassWorker;

public enum WorkLevel 
{
	unknown,
	low,
	medium,
	high,
	veryAdnvanced,
}
